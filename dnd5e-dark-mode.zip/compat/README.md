This directory contains optional, additional CSS files, designed to increase compatibility with other modules.
